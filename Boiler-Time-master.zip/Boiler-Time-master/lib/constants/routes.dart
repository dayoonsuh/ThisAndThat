const loginRoute = '/login/';
const registerRoute = '/register/';
const mainRoute = '/main/';
const verifyEmailRoute = '/verify-email/';
const forgotPasswordRoute = '/forgot-password/';
const editprofileRoute = '/edit-profile/';
