// class DemoValues {
//   static final String userImage = "assets/app-icon.png";
//   static final String postImage = "assets/app-icon.png";
//   static final String userName = "Dayoon Suh";
//   static final String userEmail = "dayoonsuh@gmail.com";
//   static final String postTime = "28 Sep, 2001";
//   static final String postTitle = "Corn";
//   static final String postSummary = "I love cornbread";
// }
