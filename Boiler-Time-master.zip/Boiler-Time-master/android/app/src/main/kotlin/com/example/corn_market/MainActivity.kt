package com.example.boiler_time

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
